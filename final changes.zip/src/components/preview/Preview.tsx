import React from 'react'

const Preview = () => {
  return (
    <div>Preview</div>
  )
}

export default Preview