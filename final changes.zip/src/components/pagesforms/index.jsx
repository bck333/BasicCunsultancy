import React, {  } from "react";
import Builder from "./builder";

const ResumeBuilder = () => {
  return (
    <>
    <Builder />
    </>
  );
};

export default ResumeBuilder;

